// src/brand-profile.ts
var PROFILE_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAMgCAYAAADbcAZoAAAbZElEQVR4nO3asbElZxWF0SEEYsDGwiMB8PFJAReXsHAwMJQAmSBhw/yl6ppSCUlzZt7b5+7utYyu7gzud/f51a9/87v/fgAAAAgQIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0Co9q9v/v7xCQBc/vHPbz785a9/+/gGr0mAUE2AAMAn3373nw9//NOfP/z72+8+fsFrEiBUEyAA8MlZPs4CAq9MgFBNgADA9054nACBVydAqCZAAMDpFV0ECNUECAA4vaKLAKGaAAHg6U54nACBFgKEagIEgCdzekUjAUI1AQLAk53l4ywg0ESAUE2AAPBUJzxOgEAbAUI1AQLAEzm9opkAoZoAAeCJzvJxFhBoJECoJkAAeJoTHidAoJUAoZoAAeBJnF5xBwKEagIEgCc5y8dZQKCZAKGaAAHgKU54nACBdgKEagIEgCdwesWdCBCqCRAAnuAsH2cBgTsQIFQTIADc3QmPEyBwFwKEagIEgDtzesUdCRCqCRAA7uwsH2cBgTsRIFQTIADc1QmPEyBwNwKEagIEgDtyesWdCRCqCRAA7ugsH2cBgTsSIFQTIADczQmPEyBwVwKEagIEgDtxesUTCBCqCRAA7uQsH2cBgTsTIFQTIADcxQmPEyBwdwKEagIEgDtwesWTCBCqCRAA7uAsH2cBgScQIFQTIAC0O+FxAgSeQoBQTYAA0MzpFU8kQKgmQABodpaPs4DAkwgQqgkQAFqd8DgBAk8jQKgmQABo5PSKJxMgVBMgADQ6y8dZQOCJBAjVBAgAbU54nACBpxIgVBMgADRxegUChHICBIAmZ/k4Cwg8mQChmgABoMUJjxMg8HQChGoCBIAGTq/gEwFCNQECQIOzfJwFBBAglBMgALy6Ex4nQIDvCRCqCRAAXpnTK/gxAUI1AQLAKzvLx1lAgE8ECNUECACv6oTHCRDghwQI1QQIAK/I6RX8NAFCNQECwCs6y8dZQIAfEyBUEyAAvJoTHidAgP9PgFBNgADwSpxewS8TIFQTIAC8krN8nAUE+GkChGoCBIBXccLjBAjw8wQI1QQIAK/A6RV8PgFCNQECwCs4y8dZQIBfJkCoJkAA2HbC4wQI8HkECNUECACbnF7BnAChmgABYNNZPs4CAnw+AUI1AQLAlhMeJ0CAGQFCNQECwAanV/DlBAjVBAgAG87ycRYQYE6AUE2AAJB2wuMECPBlBAjVBAgASU6v4OsJEKoJEACSzvJxFhDgywkQqgkQAFJOeJwAAb6OAKGaAAEgwekVvB0BQjUBAkDCWT7OAgJ8PQFCNQECwHs74XECBHgbAoRqAgSA9+T0Ct6eAKGaAAHgPZ3l4ywgwNsRIFQTIAC8lxMeJ0CAtyVAqCZAAHgPTq/g/QgQqgkQAN7DWT7OAgK8PQFCNQGy67e//8PHJwDA5xMgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoA2SVAAIApAUI1AbJLgAAAUwKEagJklwABAKYECNUEyC4BAgBMCRCqCZBdAgQAmBIgVBMguwQIADAlQKgmQHYJEABgSoBQTYDsEiAAwJQAoZoAAejgDwvgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQAA6CBDgIkCoJkAAOggQ4CJAqCZAADoIEOAiQKgmQHb5QQEATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2A7BIgAMCUAKGaANklQACAKQFCNQGyS4AAAFMChGoCZJcAAQCmBAjVBMguAQIATAkQqgmQXQIEAJgSIFQTILsECAAwJUCoJkB2CRAAYEqAUE2AAMAP/eOf33z4y1//9vENXpMAoZoAAYBPvv3uPx/++Kc/f/j3t999/ILXJECoJkAA4JOzfJwFBF6ZAKGaAAGA753wOAECr06AUE2AAIDTK7oIEKoJEABwekUXAUI1AQLA053wOAECLQQI1QQIAE/m9IpGAoRqAgSAJzvLx1lAoIkAoZoAAeCpTnicAIE2AoRqAgSAJ3J6RTMBQjUBAsATneXjLCDQSIBQTYAA8DQnPE6AQCsBQjUBAsCTOL3iDgQI1QQIAE9ylo+zgEAzAUI1AQLAU5zwOAEC7QQI1QQIAE/g9Io7ESBUEyAAPMFZPs4CAncgQKgmQAC4uxMeJ0DgLgQI1QQIAHfm9Io7EiBUEyAA3NlZPs4CAnciQKgmQAC4qxMeJ0DgbgQI1QQIAHfk9Io7EyBUEyAA3NFZPs4CAnckQKgmQAC4mxMeJ0DgrgQI1QQIAHfi9IonECBUEyAA3MlZPs4CAncmQKgmQAC4ixMeJ0Dg7gQI1QQIAHfg9IonESBUEyAA3MFZPs4CAk8gQKgmQABod8LjBAg8hQChmgABoJnTK55IgFBNgADQ7CwfZwGBJxEgVBMgALQ64XECBJ5GgFBNgADQyOkVTyZAqCZAAGh0lo+zgMATCRCqCRAA2pzwOAECTyVAqCZAAGji9AoECOUECABNzvJxFhB4MgFCNQECQIsTHidA4OkECNUECAANnF7BJwKEagIEgAZn+TgLCCBAKCdAAHh1JzxOgADfEyBUEyAAvDKnV/BjAoRqAgSAV3aWj7OAAJ8IEKoJEABe1QmPEyDADwkQqgkQAF6R0yv4aQKEagIEgFd0lo+zgAA/JkCoJkAAeDUnPE6AAP+fAKGaAAHglTi9gl8mQKgmQAB4JWf5OAsI8NMECNUECACv4oTHCRDg5wkQqgkQAF6B0yv4fAKEagIEgFdwlo+zgAC/TIBQTYAAsO2ExwkQ4PMIEKoJEAA2Ob2COQFCNQECwKazfJwFBPh8AoRqAgSALSc8ToAAMwKEagIEgA1Or+DLCRCqCRAANpzl4ywgwJwAoZoAASDthMcJEODLCBCqCRAAkpxewdcTIFQTIAAkneXjLCDAlxMgVBMgAKSc8DgBAnwdAUI1AQJAgtMreDsChGoCBICEs3ycBQT4egKEagIEgPd2wuMECPA2BAjVBAgA78npFbw9AUI1AQLAezrLx1lAgLcjQKgmQAB4Lyc8ToAAb0uAUE2AAPAenF7B+xEgVBMgALyHs3ycBQR4ewIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQI0AAAIAYAQIAAMQIEAAAIEaAAAAAMQIEAACIESAAAECMAAEAAGIECAAAECNAAACAGAECAADECBAAACBGgAAAADECBAAAiBEgAABAjAABAABiBAgAABAjQAAAgBgBAgAAxAgQAAAgRoAAAAAxAgQAAIgRIAAAQIwAAQAAYgQIAAAQ8z+eRRKVU31XYwAAAABJRU5ErkJggg==";

// src/brand.ts
var BRAND_NAME = "ENDEKS HABER";
var COLORS = { navy: "#112333", paper: "#E4E9EC", steel: "#8095A4" };
var MARK_PATH = "M88 74 H316 L292 110 H136 V172 H270 V208 H136 V270 H316 L292 306 H88 Z";

// src/card-text.ts
function normalizeCardText(value) {
  return value.replace(/\u2212/g, "-");
}

// src/report-text-metrics.ts
var widths = { "Regular": { " ": 0.26, "!": 0.269, '"': 0.408, "#": 0.646, "$": 0.572, "%": 0.831, "&": 0.732, "'": 0.225, "(": 0.3, ")": 0.3, "*": 0.551, "+": 0.572, ",": 0.268, "-": 0.322, ".": 0.268, "/": 0.372, "0": 0.572, "1": 0.572, "2": 0.572, "3": 0.572, "4": 0.572, "5": 0.572, "6": 0.572, "7": 0.572, "8": 0.572, "9": 0.572, ":": 0.268, ";": 0.268, "<": 0.572, "=": 0.572, ">": 0.572, "?": 0.434, "@": 0.899, "A": 0.639, "B": 0.65, "C": 0.632, "D": 0.73, "E": 0.556, "F": 0.519, "G": 0.728, "H": 0.741, "I": 0.339, "J": 0.273, "K": 0.619, "L": 0.524, "M": 0.907, "N": 0.76, "O": 0.781, "P": 0.605, "Q": 0.781, "R": 0.622, "S": 0.549, "T": 0.556, "U": 0.731, "V": 0.6, "W": 0.93, "X": 0.586, "Y": 0.566, "Z": 0.572, "[": 0.329, "\\": 0.372, "]": 0.329, "^": 0.572, "_": 0.444, "`": 0.281, "a": 0.561, "b": 0.615, "c": 0.48, "d": 0.615, "e": 0.564, "f": 0.344, "g": 0.615, "h": 0.618, "i": 0.258, "j": 0.258, "k": 0.534, "l": 0.258, "m": 0.935, "n": 0.618, "o": 0.605, "p": 0.615, "q": 0.615, "r": 0.413, "s": 0.479, "t": 0.361, "u": 0.618, "v": 0.508, "w": 0.786, "x": 0.529, "y": 0.51, "z": 0.47, "{": 0.38, "|": 0.551, "}": 0.38, "~": 0.572, "\u0130": 0.339, "\u0131": 0.258, "\u015E": 0.549, "\u015F": 0.479, "\u011E": 0.728, "\u011F": 0.615, "\xDC": 0.731, "\xFC": 0.618, "\xD6": 0.781, "\xF6": 0.605, "\xC7": 0.632, "\xE7": 0.48, "\u2014": 1, "\u2212": 0.6 }, "Bold": { " ": 0.26, "!": 0.286, '"': 0.472, "#": 0.646, "$": 0.572, "%": 0.901, "&": 0.75, "'": 0.266, "(": 0.339, ")": 0.339, "*": 0.545, "+": 0.572, ",": 0.285, "-": 0.322, ".": 0.285, "/": 0.413, "0": 0.572, "1": 0.572, "2": 0.572, "3": 0.572, "4": 0.572, "5": 0.572, "6": 0.572, "7": 0.572, "8": 0.572, "9": 0.572, ":": 0.285, ";": 0.285, "<": 0.572, "=": 0.572, ">": 0.572, "?": 0.477, "@": 0.897, "A": 0.69, "B": 0.672, "C": 0.637, "D": 0.74, "E": 0.56, "F": 0.549, "G": 0.724, "H": 0.765, "I": 0.389, "J": 0.331, "K": 0.664, "L": 0.565, "M": 0.943, "N": 0.813, "O": 0.796, "P": 0.628, "Q": 0.796, "R": 0.66, "S": 0.551, "T": 0.579, "U": 0.756, "V": 0.65, "W": 0.967, "X": 0.667, "Y": 0.624, "Z": 0.579, "[": 0.331, "\\": 0.413, "]": 0.331, "^": 0.572, "_": 0.411, "`": 0.362, "a": 0.604, "b": 0.633, "c": 0.514, "d": 0.633, "e": 0.591, "f": 0.387, "g": 0.633, "h": 0.657, "i": 0.305, "j": 0.305, "k": 0.62, "l": 0.305, "m": 0.982, "n": 0.657, "o": 0.619, "p": 0.633, "q": 0.633, "r": 0.454, "s": 0.497, "t": 0.434, "u": 0.657, "v": 0.569, "w": 0.856, "x": 0.578, "y": 0.569, "z": 0.488, "{": 0.394, "|": 0.551, "}": 0.394, "~": 0.572, "\u0130": 0.389, "\u0131": 0.305, "\u015E": 0.551, "\u015F": 0.497, "\u011E": 0.724, "\u011F": 0.633, "\xDC": 0.756, "\xFC": 0.657, "\xD6": 0.796, "\xF6": 0.619, "\xC7": 0.637, "\xE7": 0.514, "\u2014": 1, "\u2212": 0.6 } };
function reportTextWidth(s, size, bold = false) {
  s = s.replace(/·/g, ".");
  const table = widths[bold ? "Bold" : "Regular"];
  return [...s].reduce((n, c) => {
    if (!(c in table)) throw Error("buyback_unsupported_glyph");
    return n + table[c];
  }, 0) * size;
}

// src/market-overview-card.ts
var esc = (s) => normalizeCardText(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
var compact = (s) => s.replace(/milyar/g, "Mr").replace(/milyon/g, "Mn");
function marketOverviewCard(o, headline, theme = "paper") {
  const bg = theme === "paper" ? COLORS.paper : COLORS.navy, fg = theme === "paper" ? COLORS.navy : COLORS.paper, steel = COLORS.steel;
  const rect = (x, y, w, h, fill = bg) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="${fill}" stroke="${steel}" stroke-width="1"/>`;
  const text = (s2, x, y, size = 24, bold = false, color = fg, anchor = "start") => `<text x="${x}" y="${y}" font-size="${size}" font-weight="${bold ? 700 : 400}" fill="${color}" text-anchor="${anchor}">${esc(s2)}</text>`;
  const cell = (s2, x, y, width, size = 24, bold = false, anchor = "start") => {
    let n = size;
    while (n >= 20 && reportTextWidth(s2, n, bold) > width) n--;
    if (n < 20) throw Error("market_overview_cell_capacity");
    return text(s2, x, y, n, bold, fg, anchor);
  };
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350"><rect width="1080" height="1350" fill="${bg}"/><g font-family="Noto Sans"><image x="44" y="32" width="62" height="62" href="${PROFILE_DATA}"/>` + text("ENDEKS", 122, 61, 28, true) + text("H A B E R", 124, 86, 15, true, steel) + text("P\u0130YASA \xD6ZET\u0130", 1036, 72, 22, true, steel, "end");
  const clean = headline.replace(/^.*?—\s*/, "").trim();
  s += cell(clean, 44, 151, 992, 44, true);
  const line = (y) => `<path d="M44 ${y}H1036" stroke="${steel}"/>`;
  if (o.view === "first_moves") {
    o.panels.forEach((p, j) => {
      if (p.rows.length > 5) throw Error("market_overview_capacity");
      const y = 220 + j * 350;
      s += text(p.title, 44, y, 29, true, steel) + line(y + 20);
      p.rows.forEach((r, i) => {
        s += text(String(i + 1).padStart(2, "0"), 44, y + 75 + i * 48, 21, false, steel) + cell("#" + r.label, 110, y + 75 + i * 48, 430, 32, true) + cell(compact(r.value), 1036, y + 75 + i * 48, 420, 30, false, "end");
      });
    });
    return s + "</g></svg>";
  }
  if (o.view === "opening") {
    s += line(200) + text("BIST 100", 44, 341, 38, true, steel) + cell(o.level, 44, 505, 992, 132, true) + text("ENDEKS SEV\u0130YES\u0130", 44, 563, 25, true, steel) + line(640);
    s += cell(o.percent, 44, 818, 992, 112, true) + text(o.direction === "down" ? "D\xDC\u015E\xDC\u015E" : "Y\xDCKSEL\u0130\u015E", 44, 883, 36, true) + line(967) + text("PUAN FARKI", 44, 1041, 25, true, steel) + cell(o.points, 44, 1152, 992, 76, true) + line(1230);
    return s + "</g></svg>";
  }
  s += line(183) + text("BIST 100", 44, 227, 25, true, steel) + cell(o.level, 44, 326, 680, 90, true) + text(o.percent + " " + (o.direction === "down" ? "D\xDC\u015E\xDC\u015E" : "Y\xDCKSEL\u0130\u015E"), 1036, 240, 29, true, fg, "end") + text(o.points + " puan", 1036, 291, 28, false, fg, "end");
  s += text("HAC\u0130M " + compact(o.volume), 44, 374, 26, true) + text(o.low + " / " + o.high, 1036, 374, 25, false, fg, "end") + text("G\xDCN \u0130\xC7\u0130 D\xDC\u015E\xDCK / Y\xDCKSEK", 1036, 406, 17, true, steel, "end") + line(425);
  s += text("ENDEKSE KATKI \xB7 PUAN", 44, 463, 25, true) + text("HAC\u0130M L\u0130DERLER\u0130", 760, 463, 23, true);
  s += text("POZ\u0130T\u0130F", 44, 501, 18, true, steel) + text("NEGAT\u0130F", 392, 501, 18, true, steel);
  for (const [key, x] of [["contribution_up", 44], ["contribution_down", 392], ["volume", 760]]) {
    const p = o.panels.find((p2) => p2.key === key);
    if (!p || p.rows.length > 5) throw Error("market_overview_capacity");
    p.rows.forEach((r, i) => {
      const y = 542 + i * 43;
      s += cell("#" + r.label, x, y, key === "volume" ? 140 : 150, 24, true) + cell(compact(r.value).replace(" puan", ""), key === "volume" ? 1036 : x + 308, y, key === "volume" ? 130 : 145, 23, false, "end");
    });
  }
  s += line(746) + text("Y\xFCkselen " + o.breadth.up + "   /   N\xF6tr " + o.breadth.neutral + "   /   D\xFC\u015Fen " + o.breadth.down, 44, 784, 24) + line(806);
  for (const [b, j] of o.brokers.map((b2, i) => [b2, i])) {
    const rows = b.rows.filter((r) => !/^Diğer\s*\(/u.test(r.name));
    if (rows.length !== 5) throw Error("market_overview_capacity");
    const y = 848 + j * 236;
    s += text(b.side === "buy" ? "NET ALICI KURUMLAR" : "NET SATICI KURUMLAR", 44, y, 23, true) + text("NET HAC\u0130M", 550, y, 18, true, steel) + text("ORAN", 800, y, 18, true, steel) + text("TOPLAM TL", 1036, y, 18, true, steel, "end");
    rows.forEach((r, i) => {
      const yy = y + 38 + i * 35;
      s += cell(r.name, 44, yy, 450, 25, true) + cell(compact(r.net), 695, yy, 220, 24, false, "end") + cell(r.share, 864, yy, 140, 23, false, "end") + cell(compact(r.total).replace(/ TL$/, ""), 1036, yy, 160, 24, false, "end");
    });
    s += line(y + 208);
  }
  return s + "</g></svg>";
}

// src/output-preferences.ts
var MAX_OUTPUT_LIMIT = 999;
function outputView(d) {
  const p = d.output_preferences;
  if (!p) return d;
  if (p.list === "first" && (!Number.isInteger(p.count) || p.count < 1 || p.count > MAX_OUTPUT_LIMIT)) throw Error("invalid_output_limit");
  if (!d.card_data) return d;
  const take = (rows) => p.list === "first" ? rows.slice(0, p.count) : [...rows];
  const data = { ...d.card_data };
  for (const side of ["buy", "sell"]) if (data[side]) data[side] = p.side && p.side !== "both" && p.side !== side ? [] : take(data[side]);
  if (data.holdings) data.holdings = take(data.holdings);
  if (data.tickers) data.tickers = take(data.tickers);
  if (data.report?.buyback) {
    data.report = { ...data.report, rows: [...data.report.rows] };
    return { ...d, card_data: data };
  }
  if (data.report?.general && p.list === "first") throw Error("general_report_subset_requires_recalculation");
  if (data.report) data.report = { ...data.report, rows: take(data.report.rows), footer: p.show_footer === false ? "" : data.report.footer };
  if (!p.show_time) delete data.as_of;
  return { ...d, card_data: data };
}

// src/buyback-card.ts
var esc2 = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
function buybackLayout(n) {
  if (!Number.isInteger(n) || n < 1 || n > 200) throw Error("buyback_card_capacity_exceeded");
  const cols = n > 80 ? 3 : n > 20 ? 2 : 1, per = Math.ceil(n / cols), font = n > 100 ? 28 : 32, rowHeight = n > 100 ? 48 : 58;
  const width = 120 + cols * 1100 + (cols - 1) * 40, height = Math.max(800, 450 + per * rowHeight + 70);
  if (width > 4096 || height > 4096 || width * height > 16e6) throw Error("buyback_card_capacity_exceeded");
  return { width, height, cols, per, font, rowHeight };
}
function buybackCard(table) {
  const { width, height, cols, per, font, rowHeight } = buybackLayout(table.rows.length);
  const t = (value, x, y, size, space, bold = false, end = false) => {
    if (reportTextWidth(value, size, bold) > space - 8) throw Error("buyback_cell_capacity_exceeded");
    return `<text x="${x}" y="${y}" font-size="${size}"${bold ? ' font-weight="700"' : ""}${end ? ' text-anchor="end"' : ""}>${esc2(value)}</text>`;
  };
  let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="100%" height="100%" fill="#FFFFFF"/><g font-family="Noto Sans" fill="${COLORS.navy}"><image href="${PROFILE_DATA}" x="60" y="45" width="80" height="80"/>`;
  svg += t("ENDEKS HABER", 168, 103, 42, width - 228, true) + t("PAY GER\u0130 ALIMLARI", 60, 245, 78, width - 120, true) + t(table.day.split("-").reverse().join("."), 60, 310, 34, width - 120);
  const columns = [{ label: "H\u0130SSE", offset: 0, space: 170, end: false }, { label: "NOM\u0130NAL PAY TUTARI", offset: 490, space: 320, end: true }, { label: "ORT. F\u0130YAT (TL)", offset: 755, space: 245, end: true }, { label: "TOPLAM (TL)", offset: 1100, space: 325, end: true }];
  for (let c = 0; c < cols; c++) {
    const x = 60 + c * 1140;
    for (const col of columns) svg += t(col.label, x + col.offset, 398, 24, col.space, true, col.end);
  }
  table.rows.forEach((r, i) => {
    const c = Math.floor(i / per), line = i % per, x = 60 + c * 1140, y = 450 + line * rowHeight;
    svg += `<g data-row="${i}" data-ticker="${r.ticker}"><rect x="${x - 10}" y="${y - 38}" width="1120" height="${rowHeight - 4}" fill="${COLORS.paper}" opacity="${line % 2 ? ".35" : ".8"}"/>`;
    const values = ["#" + r.ticker, r.nominal ?? "\u2014", r.price ?? "\u2014", r.amount ?? "\u2014"];
    columns.forEach((col, j) => svg += t(values[j], x + col.offset, y, font, col.space, j === 0, col.end));
    svg += "</g>";
  });
  return svg + "</g></svg>";
}

// src/circuit-selection.ts
var CIRCUIT_REPORT_LIMIT = 40;
var code = /^[A-Z][A-Z0-9]{3,4}$/;
function circuitOmissionNote(s) {
  return s.omitted ? `${s.total_tickers} hisse; ${s.omitted} g\xF6sterilmedi.` : "";
}
function selectCircuitReport(events, indices, at, limit = CIRCUIT_REPORT_LIMIT) {
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > CIRCUIT_REPORT_LIMIT) throw Error("invalid_output_limit");
  const counts = /* @__PURE__ */ new Map();
  for (const event of events) for (const ticker of new Set(event.tickers)) {
    if (!code.test(ticker)) throw Error("circuit_report_ticker_invalid");
    counts.set(ticker, (counts.get(ticker) ?? 0) + 1);
  }
  const members = (values, n) => Array.isArray(values) && values.length === n && new Set(values).size === n && values.every((v) => typeof v === "string" && code.test(v));
  const checked = indices ? Date.parse(indices.checkedAt) : NaN;
  const verified = !!indices && indices.source === "https://www.kap.org.tr/tr/Endeksler" && members(indices.bist30, 30) && members(indices.bist100, 100) && indices.bist30.every((c) => indices.bist100.includes(c)) && Number.isFinite(checked) && checked <= at + 3e5 && at - checked <= 36 * 36e5;
  if (counts.size && !verified) throw Error("circuit_report_indices_unavailable");
  const tier = (c) => verified ? indices.bist30.includes(c) ? 30 : indices.bist100.includes(c) ? 100 : 999 : 999;
  const sorted = [...counts].sort((a, b) => tier(a[0]) - tier(b[0]) || b[1] - a[1] || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  const all_rows = sorted.map(([ticker, n]) => ({ label: "#" + ticker, value: `${n} bildirim${tier(ticker) < 999 ? " \xB7 BIST " + tier(ticker) : ""}` }));
  const rows = all_rows.slice(0, limit);
  const selection = { version: 1, rule: "bist30-bist100-repeats-code-v1", limit, total_events: events.length, total_tickers: counts.size, selected_tickers: rows.map((r) => r.label.slice(1)), omitted: counts.size - rows.length, all_rows, indices: { status: verified ? "verified" : "missing", snapshot: verified ? { bist30: [...indices.bist30], bist100: [...indices.bist100], checkedAt: indices.checkedAt, source: indices.source } : null } };
  return { rows, selection };
}

// src/report-card.ts
var esc3 = (s) => normalizeCardText(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
function reportCard(d) {
  if (d.card_data.report.kind === "range") return rangeCard(d);
  if (d.card_data.report.buyback) return buybackCard(d.card_data.report.buyback);
  if (d.card_data.report.general) return generalCard(d.card_data.report.general, d.output_preferences?.show_time === true, d.output_preferences?.show_footer !== false);
  const data = d.card_data.report, rows = data.rows, cols = 1, height = 55;
  if (rows.length > 15) throw Error("report_card_capacity_exceeded");
  const text = (s, x, y, size, color = COLORS.paper) => `<text x="${x}" y="${y}" font-size="${size}" fill="${color}">${esc3(s)}</text>`;
  let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350"><rect width="1080" height="1350" fill="${COLORS.navy}"/><g font-family="Noto Sans, sans-serif"><image href="${PROFILE_DATA}" x="64" y="52" width="64" height="64"/>` + text("ENDEKS HABER", 148, 94, 30) + text(d.headline.replace(/^📢\s*/, ""), 64, 210, 40) + text(d.body, 64, 263, 26, COLORS.steel);
  for (let c = 0; c < cols; c++) {
    const x = 64 + c * 500;
    svg += text("H\u0130SSE", x, 310, 20, COLORS.steel) + text(d.headline.includes("Devre") ? "B\u0130LD\u0130R\u0130M / ENDEKS" : "ALIM M\u0130KTARI", x + 300, 310, 20, COLORS.steel);
  }
  rows.forEach((r, i) => {
    const x = 64, y = 350 + i * height;
    if (reportTextWidth(r.label, 30, true) > 280 || reportTextWidth(r.value, 28) > 670) throw Error("report_cell_capacity_exceeded");
    svg += `<g data-report-row="${i}">` + text(r.label, x, y, 30) + text(r.value, x + 300, y, 28) + "</g>";
  });
  if (!rows.length) svg += text("Do\u011Frulanm\u0131\u015F g\xFCnl\xFCk i\u015Flem sat\u0131r\u0131 yok.", 64, 380, 32);
  const omission = data.circuit ? circuitOmissionNote(data.circuit) : "";
  const words = (omission || data.footer).split(" "), lines = [];
  let line = "";
  for (const w of words) {
    if ((line + " " + w).length > 73) {
      lines.push(line);
      line = w;
    } else line += (line ? " " : "") + w;
  }
  if (line) lines.push(line);
  if (omission || d.output_preferences?.show_footer === true || d.output_preferences?.show_footer !== false && /Pay geri alım/i.test(d.headline)) {
    if (lines.length > 2) throw Error("report_footer_capacity_exceeded");
    lines.forEach((s, i) => svg += text(s, 64, 1260 + i * 30, 26, COLORS.steel));
  }
  return svg + "</g></svg>";
}
function generalCard(g, showTime = false, showFooter = true) {
  const cols = g.rows.length > 45 ? 3 : g.rows.length > 15 ? 2 : 1, per = Math.ceil(g.rows.length / cols), width = cols * 1060 + 120, scale = width / 2200;
  const rowHeight = g.rows.length > 100 ? 52 : g.rows.length > 45 ? 58 : 64, headerHeight = 420 * scale, top = headerHeight + 105, height = Math.ceil(Math.max(1100, top + per * rowHeight + 150));
  const t = (s, x, y, size, color = COLORS.navy, anchor = "start") => `<text x="${x}" y="${y}" text-anchor="${anchor}" font-size="${size}" fill="${color}">${esc3(s)}</text>`;
  let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="100%" height="100%" fill="#FFFFFF"/><g font-family="Noto Sans, sans-serif"><g transform="scale(${scale})"><image href="${PROFILE_DATA}" x="60" y="42" width="100" height="100"/><g font-weight="700">` + t("ENDEKS HABER", 190, 116, 58) + t("PAY GER\u0130 ALIMLARI", 60, 260, 96) + "</g>" + t(g.day + (showTime ? " \u2022 " + g.time + " itibar\u0131yla" : ""), 60, 314, 34);
  if (width * height > 48e6 || width > 16384 || height > 16384) throw Error("general_card_capacity_exceeded");
  const metrics = [["H\u0130SSE" + (g.partial ? " (KISM\u0130)" : ""), String(g.companies)], ["TOPLAM LOT" + (g.partial ? " (KISM\u0130)" : ""), g.lots], ["TOPLAM TUTAR" + (g.missing || g.partial ? " (KISM\u0130)" : ""), g.amount + " TL"]];
  metrics.forEach(([label, value], i) => {
    const x = 60 + i * 2080 / 3;
    svg += t(label, x, 375, 25) + t(value, x, 426, 40);
  });
  svg += "</g>";
  const font = g.rows.length > 100 ? 26 : 28;
  for (let c = 0; c < cols; c++) {
    const x = 60 + c * 1060, y = headerHeight + 55;
    svg += `<g font-weight="700">` + t("H\u0130SSE", x, y, 24) + t("LOT", x + 420, y, 24, COLORS.navy, "end") + t("ORT. F\u0130YAT (TL)", x + 690, y, 24, COLORS.navy, "end") + t("TUTAR (TL)", x + 1e3, y, 24, COLORS.navy, "end") + "</g>";
  }
  g.rows.forEach((r, i) => {
    if (reportTextWidth("#" + r.ticker, font + 2) > 200 || reportTextWidth(r.lots, font) > 220 || reportTextWidth(r.price, font) > 250 || reportTextWidth(r.amount, font) > 290) throw Error("general_cell_capacity_exceeded");
    const c = Math.floor(i / Math.max(1, per)), line = i % Math.max(1, per), x = 60 + c * 1060, y = top + line * rowHeight;
    svg += `<rect x="${x - 12}" y="${y - 35}" width="1030" height="${rowHeight - 4}" fill="${COLORS.navy}" opacity="${line % 2 ? ".025" : ".065"}"/>` + t("#" + r.ticker, x, y, font + 2) + t(r.lots, x + 420, y, font, COLORS.navy, "end") + t(r.price, x + 690, y, font, COLORS.navy, "end") + t(r.amount, x + 1e3, y, font, COLORS.navy, "end");
  });
  if (!g.rows.length) svg += t("Do\u011Frulanm\u0131\u015F g\xFCnl\xFCk i\u015Flem sat\u0131r\u0131 yok.", 60, top, 32);
  if (showFooter) svg += t("Yaln\u0131z KAP pay geri al\u0131m\u0131 bildirimleri esas al\u0131nm\u0131\u015Ft\u0131r. Farkl\u0131l\u0131k g\xF6sterebilir.", 60, height - 82, 24) + t(g.partial ? "Toplay\u0131c\u0131 kapsam\u0131 k\u0131smi; yaln\u0131z kay\u0131tl\u0131 i\u015Flemler g\xF6sterilir." : g.missing ? "Eksik fiyatlar \u2014 ile g\xF6sterilir. Toplam tutar k\u0131smi olabilir." : "Ortalama fiyat lot a\u011F\u0131rl\u0131kl\u0131d\u0131r. Tutar i\u015Flem sat\u0131rlar\u0131ndan hesaplanm\u0131\u015Ft\u0131r.", 60, height - 40, 24);
  return svg + "</g></svg>";
}
function rangeCard(d) {
  const rows = d.card_data.report.rows;
  if (rows.length > 15) throw Error("report_card_capacity_exceeded");
  const t = (s, x, y, size, color = COLORS.paper) => `<text x="${x}" y="${y}" font-size="${size}" fill="${color}">${esc3(s)}</text>`;
  let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350"><rect width="1080" height="1350" fill="${COLORS.navy}"/><g font-family="Noto Sans, sans-serif"><image href="${PROFILE_DATA}" x="64" y="52" width="64" height="64"/>` + t("ENDEKS HABER", 148, 94, 30) + t("BIST 30 \u2022 100 G\xDCNL\xDCK D\u0130P\u2013Z\u0130RVE", 64, 210, 38);
  const xs = [64, 240, 420, 600, 810];
  ["H\u0130SSE", "D\u0130P (TL)", "Z\u0130RVE (TL)", "D\u0130BE UZAKLIK", "Z\u0130RVEYE UZAKLIK"].forEach((s, i) => svg += t(s, xs[i], 310, 21, COLORS.steel));
  rows.forEach((r, i) => {
    const cells = [r.label, ...r.value.split("|")];
    if (cells.length !== 5) throw Error("gallery_cell_missing");
    cells.forEach((v, j) => {
      const text = j > 2 ? "%" + v : v;
      if (reportTextWidth(text, 27) > [160, 160, 160, 190, 205][j]) throw Error("report_cell_capacity_exceeded");
      svg += t(text, xs[j], 365 + i * 55, 27);
    });
  });
  return svg + "</g></svg>";
}

// src/akd-columns.ts
function akdColumns(row) {
  const number = "[-+\u2212]?\\d+(?:[.,]\\d+)*";
  const parts = row.value.split(/[·|;]/).map((v) => v.trim());
  if (parts.length >= 2 && parts.length <= 3) {
    const ratio = parts[0].match(new RegExp(`^(%${number}|${number}%)$`, "iu"))?.[1] ?? null;
    const q = parts.find((v) => new RegExp(`^${number}\\s*(?:lot|adet|pay)$`, "iu").test(v));
    const quantity = q?.match(new RegExp(`^(${number})\\s*(lot|adet|pay)$`, "iu"));
    const cost = parts.find((v) => new RegExp(`^${number}(?:\\s*(?:TL|\u20BA))?$`, "iu").test(v) && v !== q && v !== parts[0]) ?? null;
    if (ratio || quantity || cost) return { ratio, quantity: quantity?.[1] ?? null, unit: quantity?.[2].toLocaleLowerCase("tr-TR") ?? null, cost };
  }
  const amount = new RegExp(`^\\s*(${number})\\s*(lot|adet|pay)(?:\\s+net\\s+(?:sat\u0131\u015F|sat\u0131m|al\u0131\u015F|al\u0131m))?\\s*$`, "iu").exec(row.value);
  return amount ? { ratio: null, quantity: amount[1], unit: amount[2].toLocaleLowerCase("tr-TR"), cost: null } : null;
}

// src/card-layout.ts
var CARD_LAYOUTS = ["editorial", "frame", "rail", "masthead", "center", "brief"];

// src/market-card.ts
var esc4 = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
function marketCard(d, theme, layout, fit) {
  if (d.template === "circuit") return circuitCard("navy", "editorial", d.card_data?.tickers ?? []);
  const bg = COLORS[theme], fg = theme === "navy" ? COLORS.paper : COLORS.navy, steel = COLORS.steel;
  const data = d.card_data, variant = CARD_LAYOUTS.indexOf(layout), left = layout === "rail" ? 122 : 76, width = 1080 - left - 76;
  const rect = (x, y, w, h, fill, stroke) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}"${stroke ? ` stroke="${stroke}" stroke-width="2"` : ""}/>`;
  const text = (s, x, y, size, color = fg, weight = 400, anchor = "start") => `<text x="${x}" y="${y}" font-size="${size}" font-weight="${weight}" fill="${color}" text-anchor="${anchor}">${esc4(s.replace(/−/g, "-"))}</text>`;
  const rule = (y) => `<path d="M${left} ${y} H1004" stroke="${steel}" stroke-width="1"/>`;
  const block = (s, x, y, w, h, size = 40, color = fg, min = 26, weight = 400, align2) => fit(s.replace(/−/g, "-"), { x, y, width: w, height: h, size, min, weight, color, align: align2 });
  const summary = d.template === "institutional" && !!(data?.buy_broker || data?.sell_broker);
  const labels = { circuit: "DEVRE KES\u0130C\u0130", institutional: summary ? "KURUM AKD \xD6ZET\u0130" : data?.buy?.length && !data?.sell?.length ? "KURUM / ALIM" : data?.sell?.length && !data?.buy?.length ? "KURUM / SATIM" : "KURUM ALIM / SATIM", akd: "H\u0130SSE / AKD", volume: "\u0130\u015ELEM HACM\u0130", broker_flow: "ARACI KURUM / NET \u0130\u015ELEM", custody: "TAKAS / SAKLAMA", theoretical: "TEOR\u0130K E\u015ELE\u015EME" };
  const inverse = layout === "brief" || layout === "masthead";
  let art = layout === "frame" ? rect(34, 34, 1012, 1282, "none", steel) : layout === "rail" ? rect(0, 0, 38, 1350, fg) + rect(38, 0, 6, 1350, steel) : "";
  if (inverse) art += rect(0, 0, 1080, 180, fg);
  art += `<image x="${left}" y="58" width="68" height="68" href="${PROFILE_DATA}"/>` + text("ENDEKS", left + 90, 88, 30, inverse ? bg : fg, 700) + text("H A B E R", left + 92, 116, 17, steel, 700) + text(labels[d.template], 1004, 102, 22, inverse ? bg : steel, 700, "end");
  art += rule(182);
  if (data?.as_of) art += text(data.as_of, left, 222, 24, steel);
  const centered = layout === "center", align = centered ? "center" : void 0;
  const separateTicker = data?.ticker && !d.headline.includes(data.ticker);
  if (d.template === "volume") {
    art += block(d.headline, left, 276, width, 200, 65, fg, 42, 700, align);
    if (separateTicker) art += text(data.ticker, 1004, 505, 32, steel, 700, "end");
    const hero = data?.metrics?.[0];
    if (hero) {
      art += text(hero.label, left, 557, 27, steel, 700) + block(hero.value, left, 592, width, 180, 114, fg, 60, 700);
    } else art += `<path d="${MARK_PATH}" transform="translate(380 500) scale(.75)" fill="${steel}" opacity=".20"/>`;
    let y = 836;
    for (const row of data?.metrics?.slice(1, 3) ?? []) {
      art += rule(y - 20) + text(row.label, left, y + 16, 27, steel) + text(row.value, 1004, y + 22, 36, fg, 700, "end");
      y += 110;
    }
    art += rule(1110) + block(d.body, left, 1150, width, 150, 32, fg, 26);
  } else if (d.template === "theoretical") {
    art += block(d.headline, left, 268, width, 155, 61, fg, 38, 700, align);
    const table = (title, rows, y, invert) => {
      if (!rows?.length) return "";
      if (rows.length > 5) throw Error("market_card_capacity_theoretical");
      const ink = invert ? bg : fg, muted = invert ? bg : steel, x = left + 24, inner = width - 48, bounds = [0, 0.24, 0.5, 0.72, 1];
      let svg = rect(left, y, width, 365, invert ? fg : bg, invert ? void 0 : steel) + text(title, x, y + 43, 25, muted, 700);
      ["H\u0130SSE", "TEOR\u0130K F\u0130YAT", "DE\u011E\u0130\u015E\u0130M", "KALAN"].forEach((h, j) => svg += text(h, x + bounds[j] * inner, y + 83, 20, muted, 700));
      rows.forEach((r, i) => {
        const cells = [r.label, ...r.value.split("|")];
        if (cells.length !== 4) throw Error("theoretical_cell_missing");
        cells.forEach((v, j) => svg += block(v.trim(), x + bounds[j] * inner, y + 110 + i * 49, (bounds[j + 1] - bounds[j]) * inner - 12, 48, 24, ink, 20, j === 0 ? 700 : 400));
      });
      return svg;
    };
    art += table("TEOR\u0130K Y\xDCKSELENLER", data?.buy, 480, layout !== "masthead") + table("TEOR\u0130K D\xDC\u015EENLER", data?.sell, 860, layout === "masthead");
  } else if (d.template === "custody") {
    if ((data?.holdings?.length ?? 0) > 5) throw Error("market_card_capacity_custody");
    art += block(d.headline, left, 268, width, 155, 61, fg, 38, 700, align);
    if (separateTicker) art += text(data.ticker, 1004, 455, 32, steel, 700, "end");
    const hero = data?.metrics?.[0];
    if (hero) art += text(hero.label, left, 500, 26, steel, 700) + block(hero.value, left, 530, width, 120, 78, fg, 44, 700);
    if (data?.holdings?.length) {
      art += rect(left, 710, width, 440, fg) + text("SAKLAMA KURULU\u015ELARI", left + 28, 755, 25, bg, 700);
      data.holdings.forEach((r, i) => {
        const y = 778 + i * 70;
        art += block(r.label, left + 28, y, width * 0.4, 60, 29, bg, 20, 700) + block(r.value, left + width * 0.45, y, width * 0.55 - 28, 60, 28, bg, 18);
      });
      art += block(d.body, left, 1190, width, 110, 29, fg, 22);
    } else art += block(d.body, left, 735, width, 430, 45, fg, 28);
  } else if (d.template === "akd" && (data?.buy?.length || data?.sell?.length)) {
    art += block(d.headline, left, 268, width, 155, 61, fg, 38, 700, align);
    if (separateTicker) art += text(data.ticker, 1004, 446, 32, steel, 700, "end");
    const table = (title, rows, y, invert) => {
      if (!rows?.length) return "";
      if (rows.length > 5) throw Error("market_card_capacity_akd");
      const ink = invert ? bg : fg, muted = invert ? bg : steel, parsed = rows.map(akdColumns), structured = parsed.every(Boolean);
      const units = new Set(parsed.flatMap((p) => p?.unit ? [p.unit] : [])), unit = units.size === 1 ? [...units][0] : void 0;
      const bounds = structured ? [0, 0.29, 0.46, 0.79, 1] : [0, 0.48, 1];
      const headers = structured ? ["KURUM", "ORAN", unit === "lot" ? "NET LOT" : unit === "adet" ? "NET ADET" : unit === "pay" ? "NET PAY" : "NET M\u0130KTAR"] : ["KURUM", "VER\u0130"];
      if (structured) headers.push("MAL\u0130YET");
      const inner = width - 48, x = left + 24;
      let svg = rect(left, y, width, 365, invert ? fg : bg, invert ? void 0 : steel) + text(title, x, y + 43, 25, muted, 700);
      headers.forEach((h, i) => {
        svg += text(h, x + bounds[i] * inner, y + 83, 20, muted, 700);
      });
      svg += `<path d="M${x} ${y + 96} H${left + width - 24}" stroke="${muted}" stroke-width="1" opacity=".45"/>`;
      rows.forEach((r, i) => {
        const p = parsed[i], values = structured ? [r.label, p?.ratio ?? "\u2014", p?.quantity ? p.unit ? `${p.quantity} ${unit || p.unit}` : p.quantity : "\u2014", p?.cost ?? "\u2014"] : [r.label, r.value];
        values.forEach((v, j) => {
          svg += block(v, x + bounds[j] * inner, y + 110 + i * 49, (bounds[j + 1] - bounds[j]) * inner - 12, 48, j === 0 ? 27 : 25, ink, j === 0 ? 18 : 17, j === 0 ? 700 : 400);
        });
      });
      return svg;
    };
    art += table("ALICI KURUMLAR", data.buy, 480, layout !== "masthead") + table("SATICI KURUMLAR", data.sell, 860, layout === "masthead");
  } else if (d.template === "broker_flow" && (data?.buy?.length || data?.sell?.length)) {
    art += block(d.headline, left, 268, width, 155, 61, fg, 38, 700, align);
    if (separateTicker) art += text(data.ticker, 1004, 446, 32, steel, 700, "end");
    const table = (title, rows, y, invert) => {
      if (!rows?.length) return "";
      if (rows.length > 5) throw Error("market_card_capacity_broker_flow");
      const ink = invert ? bg : fg;
      let svg = rect(left, y, width, 310, invert ? fg : bg, invert ? void 0 : steel) + text(title, left + 28, y + 46, 25, invert ? bg : steel, 700);
      rows.forEach((row, i) => {
        const top = y + 69 + i * 46;
        svg += block(row.label, left + 28, top, width - 360, 46, 30, ink, 18, 700) + block(row.value, 1004 - 300, top, 272, 46, 30, ink, 18);
      });
      return svg;
    };
    art += table(d.template === "broker_flow" ? "NET ALICI KURUMLAR" : "ALICI KURUMLAR", data.buy, 480, layout !== "masthead") + table(d.template === "broker_flow" ? "NET SATICI KURUMLAR" : "SATICI KURUMLAR", data.sell, 836, layout === "masthead");
    art += block(d.body, left, 1190, width, 105, 30, fg, 22);
  } else if (summary && (data?.buy?.length || data?.sell?.length)) {
    art += block(d.headline, left, 260, width, 130, 55, fg, 38, 700, align);
    const table = (role, broker, rows, y, invert) => {
      if (!rows?.length) return "";
      if (rows.length > 5) throw Error("market_card_capacity_institution_summary");
      const ink = invert ? bg : fg, muted = invert ? bg : steel, x = left + 28, inner = width - 56, bounds = [0, 0.3, 0.65, 1], height = 154 + rows.length * 46 + 12;
      let svg = rect(left, y, width, height, invert ? fg : bg, invert ? void 0 : steel) + text(role, x, y + 38, 25, muted, 700);
      svg += block(broker + " \xFCzerinden \xF6ne \xE7\u0131kan hisseler", x, y + 52, inner, 48, 28, ink, 20, 700);
      ["H\u0130SSE", "NET HAC\u0130M", "MAL\u0130YET"].forEach((h, j) => svg += text(h, x + bounds[j] * inner, y + 125, 21, muted, 700));
      svg += `<path d="M${x} ${y + 138} H${left + width - 28}" stroke="${muted}" stroke-width="1" opacity=".45"/>`;
      rows.forEach((row, i) => {
        const cells = [row.label, ...institutionSummaryCells(row.value)];
        cells.forEach((v, j) => svg += block(v, x + bounds[j] * inner, y + 150 + i * 46, (bounds[j + 1] - bounds[j]) * inner - 16, 44, j === 0 ? 30 : 27, ink, 22, j === 0 ? 700 : 400));
      });
      return svg;
    };
    const buyHeight = data?.buy?.length ? 154 + data.buy.length * 46 + 12 : 0;
    art += table("EN \xC7OK NET ALIM", data?.buy_broker ?? data?.broker ?? "Kurum", data?.buy, 420, layout !== "masthead");
    art += table("EN \xC7OK NET SATIM", data?.sell_broker ?? data?.broker ?? "Kurum", data?.sell, buyHeight ? 420 + buyHeight + 26 : 420, layout === "masthead");
  } else if (d.template === "institutional" && (data?.buy?.length || data?.sell?.length)) {
    art += block(d.headline, left, 268, width, 192, 61, fg, 38, 700, align);
    const both = !!(data.buy?.length && data.sell?.length), gap = 26, col = both ? (width - gap) / 2 : width;
    if ((data.buy?.length ?? 0) > 10 || (data.sell?.length ?? 0) > 10) throw Error("market_card_capacity_institutional");
    const brokerId = (data.broker ?? "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    const brokerLabel = ["BANKOFAMERICA", "BOFA"].includes(brokerId) ? "BofA" : "KURUM";
    const panel = (title, rows, x, invert) => {
      if (!rows?.length) return "";
      const ink = invert ? bg : fg;
      let svg = rect(x, 510, col, 650, invert ? fg : bg, invert ? void 0 : steel) + text(title, x + 22, 558, 22, invert ? bg : steel, 700);
      rows.forEach((r, i) => {
        const y = 590 + i * 54, labelWidth = both ? /^[A-Z][A-Z0-9]{3,4}$/.test(r.label) ? 105 : col * 0.45 : col * 0.35;
        svg += block(r.label, x + 22, y, labelWidth, 48, both ? 29 : 33, ink, 22, 700);
        svg += block(r.value, x + 32 + labelWidth, y, col - labelWidth - 54, 48, both ? 25 : 33, ink, both ? 18 : 23);
      });
      return svg;
    };
    art += panel(`${data.buy_broker ?? brokerLabel} \xDCZER\u0130NDEN ALIM`, data.buy, left, layout !== "masthead") + panel(`${data.sell_broker ?? brokerLabel} \xDCZER\u0130NDEN SATIM`, data.sell, both ? left + col + gap : left, layout === "masthead");
  } else {
    art += block(d.headline, left, 268, width, 192, 61, fg, 38, 700, align);
    if (data?.ticker) art += text(data.ticker, 1004, 486, 34, fg, 700, "end");
    const gap = 26, col = (width - gap) / 2, start = 535;
    const panel = (title, rows, x, invert) => {
      if (!rows?.length) return "";
      if (rows.length > 5) throw Error("market_card_capacity_market");
      const ink = invert ? bg : fg, paper = invert ? fg : bg;
      let svg = rect(x, start, col, 530, paper, invert ? void 0 : steel) + text(title, x + 25, start + 47, 25, invert ? bg : steel, 700);
      for (let i = 0; i < rows.length; i++) {
        const y = start + 82 + i * 85;
        svg += block(rows[i].label, x + 25, y, col - 50, 38, d.template === "akd" ? 28 : 35, ink, 23, 700);
        svg += block(rows[i].value, x + 25, y + 40, col - 50, 38, 30, ink, 22);
      }
      return svg;
    };
    if (data?.buy?.length || data?.sell?.length) {
      art += panel(d.template === "akd" ? "ALICI KURUMLAR" : "EN \xC7OK ALINAN", data.buy, left, layout !== "masthead");
      art += panel(d.template === "akd" ? "SATICI KURUMLAR" : "EN \xC7OK SATILAN", data.sell, left + col + gap, layout === "masthead");
    } else art += block(d.body, left, 586, width, 420, 48, fg, 32);
    if (data?.buy?.length || data?.sell?.length) art += rule(1120) + block(d.body, left, 1160, width, 150, 31, fg, 25);
  }
  art += `<path d="M${left} 1308 H${left + 56 + variant * 22}" stroke="${steel}" stroke-width="${layout === "brief" ? 7 : 3}"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1080" height="1350" viewBox="0 0 1080 1350" role="img"><title>${BRAND_NAME} \u2014 ${esc4(d.headline)}</title>${rect(0, 0, 1080, 1350, bg)}<g font-family="Noto Sans">${art}</g></svg>`;
}
function circuitCard(theme, layout, tickers) {
  if (!Array.isArray(tickers) || tickers.some((c) => typeof c !== "string" || !/^[A-Z][A-Z0-9]{3,4}$/.test(c))) throw Error("invalid_circuit_tickers");
  const codes = [...new Set(tickers)], dense = codes.length > 24;
  const bg = COLORS[theme], ink = theme === "navy" ? COLORS.paper : COLORS.navy, steel = COLORS.steel;
  const centered = layout === "center", x = centered ? 540 : layout === "rail" ? 130 : 80, anchor = centered ? "middle" : "start";
  const panel = layout === "brief" || layout === "masthead", fg = panel ? bg : ink;
  const frame = layout === "frame" ? `<rect x="32" y="32" width="1016" height="1286" fill="none" stroke="${steel}" stroke-width="2"/>` : layout === "rail" ? `<rect width="24" height="1350" fill="${ink}"/><rect x="24" width="6" height="1350" fill="${steel}"/>` : "";
  const left = layout === "rail" ? 130 : 80, width = 1e3 - left;
  const y = dense ? 370 : codes.length > 6 ? 450 : layout === "brief" ? 540 : layout === "masthead" ? 570 : centered ? 565 : 550;
  const size = dense ? 86 : codes.length > 6 ? 148 : 174;
  const listTop = dense ? 480 : codes.length > 6 ? 720 : 830, listHeight = 1250 - listTop;
  let grid = "";
  if (codes.length) {
    const tags = codes.map((c) => "#" + c), gap = dense ? 10 : 14;
    let settings;
    for (const font2 of [44, 40, 36, 32, 30, 28, 26, 24, 22]) {
      const cell2 = Math.ceil(Math.max(...tags.map((t) => [...t].reduce((n, c) => n + (/[MW]/.test(c) ? 0.98 : /[IL1]/.test(c) ? 0.4 : 0.75), 0) * font2))) + (dense ? 12 : 28);
      const columns2 = Math.min(codes.length, Math.max(1, Math.floor((width + gap) / (cell2 + gap)))), row2 = Math.ceil(font2 * 1.25) + (dense ? 6 : 16);
      if (Math.ceil(codes.length / columns2) * row2 <= listHeight) {
        settings = { font: font2, cell: cell2, columns: columns2, row: row2 };
        break;
      }
    }
    if (!settings) throw Error("circuit_card_capacity");
    const { font, cell, columns, row } = settings, total = columns * cell + (columns - 1) * gap, start = centered ? left + (width - total) / 2 : left;
    grid = tags.map((tag, i) => {
      const tx = start + i % columns * (cell + gap), ty = listTop + Math.floor(i / columns) * row;
      return `<g data-circuit-ticker="${esc4(codes[i])}"><rect x="${tx}" y="${ty}" width="${cell}" height="${row - 6}" fill="none" stroke="${steel}" stroke-width="1"/><text x="${tx + cell / 2}" y="${ty + (row - 6) / 2 + font * 0.34}" font-size="${font}" font-weight="700" text-anchor="middle" fill="${ink}">${esc4(tag)}</text></g>`;
    }).join("");
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350" role="img"><title>${BRAND_NAME} \u2014 DEVRE KES\u0130C\u0130</title>
 <rect width="1080" height="1350" fill="${bg}"/>${frame}
 <image x="80" y="66" width="76" height="76" href="${PROFILE_DATA}"/>
 <g font-family="Noto Sans"><text x="178" y="103" font-size="36" font-weight="700" fill="${ink}">ENDEKS</text><text x="180" y="136" font-size="20" font-weight="700" letter-spacing="6" fill="${steel}">HABER</text>
 <path d="M80 192 H1000" stroke="${steel}" stroke-width="1"/>
 ${panel ? `<rect x="48" y="${dense ? 246 : codes.length > 6 ? 270 : 310}" width="984" height="${dense ? 180 : codes.length > 6 ? 395 : 470}" fill="${ink}"/>` : ""}
 <path d="M${centered ? 474 : x} ${y - (dense ? 120 : 180)} h132" stroke="${steel}" stroke-width="${dense ? 8 : 12}"/>
 ${dense ? `<text x="${x}" y="${y}" font-size="${size}" font-weight="700" letter-spacing="-2" text-anchor="${anchor}" fill="${fg}">DEVRE KES\u0130C\u0130</text>` : `<text x="${x}" y="${y}" font-size="${size}" font-weight="700" letter-spacing="-5" text-anchor="${anchor}" fill="${fg}">DEVRE</text><text x="${x}" y="${y + size + 22}" font-size="${size}" font-weight="700" letter-spacing="-5" text-anchor="${anchor}" fill="${fg}">KES\u0130C\u0130</text>`}
 ${grid}
 <path d="M80 1300 H1000" stroke="${steel}" stroke-width="1"/><path d="M80 1300 H${240 + CARD_LAYOUTS.indexOf(layout) * 28}" stroke="${ink}" stroke-width="6"/>
 </g></svg>`;
}
function institutionSummaryCells(value) {
  const match = /^(.*?)\s*(?:[·|;]\s*)?maliyet\s*:?\s*(.+)$/iu.exec(value);
  if (match) {
    const net = match[1].trim().replace(/[·|;]\s*$/u, "").trim().replace(/^net hacim\s*[:=]?\s*/iu, "").replace(/\s+net hacim$/iu, "");
    if (!net || !match[2].trim()) throw Error("institution_summary_cells_invalid");
    return [net, match[2].trim()];
  }
  if (/[·|;]/u.test(value)) throw Error("institution_summary_cells_invalid");
  return [value.trim() || "\u2014", "\u2014"];
}

// src/card-theme.ts
function legacyTheme(template) {
  return template === "info" || template === "economic_data" || template === "market" ? "paper" : "navy";
}

// src/card.ts
var esc5 = (s) => normalizeCardText(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
var measure = (s, size) => [...s].reduce((n, c) => n + (/[MW@%]/.test(c) ? 0.94 : /[ilıİ.,:;!' ]/.test(c) ? 0.32 : /[A-ZÇĞÖŞÜ0-9]/.test(c) ? 0.69 : 0.59), 0) * size;
function wrap(text, size, width) {
  text = normalizeCardText(text);
  const words = text.trim().split(/\s+/).filter(Boolean);
  if (words.some((w) => measure(w, size) > width)) throw new Error("card_word_overflow");
  const greedy = [];
  let line = "";
  for (const word of words) {
    const next = line ? line + " " + word : word;
    if (measure(next, size) > width && line) {
      greedy.push(line);
      line = word;
    } else line = next;
  }
  if (line) greedy.push(line);
  if (greedy.length < 2 || greedy.length > 10) return greedy;
  const target = measure(words.join(" "), size) / greedy.length;
  const memo = /* @__PURE__ */ new Map();
  function solve(start, left) {
    if (!left) return start === words.length ? { cost: 0, lines: [] } : null;
    const key = `${start}:${left}`;
    if (memo.has(key)) return memo.get(key);
    let best = null;
    for (let end = start + 1; end <= words.length - left + 1; end++) {
      const value = words.slice(start, end).join(" "), w = measure(value, size);
      if (w > width) break;
      const tail = solve(end, left - 1);
      if (!tail) continue;
      const cost = (w - target) ** 2 + (end - start === 1 && words.length > greedy.length ? width ** 2 * 0.18 : 0) + tail.cost;
      if (!best || cost < best.cost) best = { cost, lines: [value, ...tail.lines] };
    }
    memo.set(key, best);
    return best;
  }
  return solve(0, greedy.length)?.lines ?? greedy;
}
function draftCard(d, sources = [], date = "", demo = false, theme, layout = "editorial") {
  return cardSvg({ headline: d.card_headline, body: d.card_body, template: d.template, card_data: d.card_data, output_preferences: d.output_preferences }, sources, date, demo, theme, layout);
}
function cardSvg(d, _sources = [], _date = "", _demo = false, theme, layout = "editorial") {
  d = outputView(d);
  if (!d.output_preferences?.show_time && d.card_data?.as_of) {
    d = { ...d, card_data: { ...d.card_data } };
    delete d.card_data.as_of;
  }
  if (d.card_data?.overview) return marketOverviewCard(d.card_data.overview, d.headline, theme);
  if (d.card_data?.report) return reportCard(d);
  const headline = d.headline.replace(/^(?:\p{Extended_Pictographic}\uFE0F?\s*)+/u, "").trim();
  if (!headline || !d.body.trim()) throw new Error("card_content_empty");
  if (["circuit", "institutional", "akd", "volume", "broker_flow", "custody", "theoretical"].includes(d.template)) return marketCard({ ...d, headline }, theme ?? legacyTheme(d.template), layout, fitText);
  const label = templateLabel(d.template), special = d.template === "breaking" || d.template === "circuit";
  const dark = (theme ?? legacyTheme(d.template)) === "navy";
  const bg = dark ? COLORS.navy : COLORS.paper, fg = dark ? COLORS.paper : COLORS.navy;
  if (layout !== "editorial") return alternateCard(headline, d.body, special, bg, fg, layout, label);
  const bodySize = 36, bodyLines = wrap(d.body, bodySize, 848);
  if (bodyLines.length > 6) throw new Error("card_content_overflow");
  const bodyHeight = Math.max(290, bodyLines.length * 53 + 114), panelY = 1350 - bodyHeight;
  const top = special ? 310 : 270, bottom = panelY - 90, available = bottom - top;
  const preferredLines = headline.length > 80 ? 5 : headline.length > 64 ? 4 : 3;
  let size = 108, lines = [];
  for (; size >= 60; size -= 2) {
    try {
      lines = wrap(headline, size, 920);
    } catch (e) {
      if (size === 60) throw e;
      continue;
    }
    if (lines.length <= (size === 60 ? 7 : preferredLines) && lines.length * size * 1.14 <= available) break;
  }
  if (size < 60) throw new Error("card_content_overflow");
  const headlineY = top + Math.max(0, (available - lines.length * size * 1.14) * 0.38) + size * 0.86;
  const text = (values, x, y, fontSize, lineHeight, weight, color) => values.map((v, i) => `<text x="${x}" y="${Math.round(y + i * lineHeight)}" font-size="${fontSize}" font-weight="${weight}" fill="${color}">${esc5(v)}</text>`).join("");
  const signature = `<path d="${MARK_PATH}" transform="translate(740 -40) scale(.85)" fill="${COLORS.steel}" opacity=".10"/>`;
  const panelBg = dark ? COLORS.paper : COLORS.navy, panelFg = dark ? COLORS.navy : COLORS.paper;
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1080" height="1350" viewBox="0 0 1080 1350" role="img" aria-labelledby="card-title">
 <title id="card-title">${BRAND_NAME} \u2014 ${esc5(headline)}</title>
 <rect width="1080" height="1350" fill="${bg}"/>
 ${signature}
 <image x="76" y="66" width="80" height="80" xlink:href="${PROFILE_DATA}"/>
 <g font-family="Noto Sans">
 <text x="178" y="107" fill="${fg}" font-size="38" font-weight="700" letter-spacing="1">ENDEKS</text>
 <text x="180" y="139" fill="${COLORS.steel}" font-size="22" font-weight="700" letter-spacing="7">HABER</text>
 <path d="M76 192 H1004" stroke="${COLORS.steel}" stroke-width="1" opacity=".45"/>
 <path d="M76 192 H156" stroke="${fg}" stroke-width="5"/>
 ${special ? `<rect x="76" y="236" width="12" height="12" fill="${COLORS.steel}"/><text x="106" y="251" fill="${fg}" font-size="22" font-weight="700" letter-spacing="3">${esc5(label)}</text>` : ""}
 ${text(lines, 76, headlineY, size, size * 1.14, 700, fg)}
 <rect y="${panelY}" width="1080" height="${bodyHeight}" fill="${panelBg}"/>
 <path d="M76 ${panelY} H192" stroke="${COLORS.steel}" stroke-width="8"/>
 <path d="M76 ${panelY + 64} V${panelY + bodyHeight - 64}" stroke="${COLORS.steel}" stroke-width="2"/>
 ${text(bodyLines, 112, panelY + 88, bodySize, 53, 400, panelFg)}
 </g></svg>`;
}
function templateLabel(template) {
  return { breaking: "SON DAK\u0130KA", circuit: "DEVRE KES\u0130C\u0130", kap: "KAP B\u0130LD\u0130R\u0130M\u0130", company: "\u015E\u0130RKET HABERLER\u0130", market: "BIST / P\u0130YASA", finance: "EKONOM\u0130 / F\u0130NANS", economic_data: "EKONOM\u0130K VER\u0130", global: "K\xDCRESEL P\u0130YASALAR", info: "B\u0130LG\u0130 / \u0130STAT\u0130ST\u0130K", news: "HABER", institutional: "KURUM ALIM / SATIM", akd: "ARACI KURUM DA\u011EILIMI", volume: "\u0130\u015ELEM HACM\u0130", broker_flow: "ARACI KURUM / NET \u0130\u015ELEM", custody: "TAKAS / SAKLAMA", theoretical: "TEOR\u0130K E\u015ELE\u015EME" }[template];
}
function fitText(value, b) {
  for (let size = b.size; size >= b.min; size -= 2) {
    let lines;
    try {
      lines = wrap(value, size, b.width);
    } catch {
      continue;
    }
    const leading = size * 1.2;
    if (lines.length * leading > b.height) continue;
    const x = b.align === "center" ? b.x + b.width / 2 : b.x;
    return lines.map((line, i) => `<text x="${x}" y="${Math.round(b.y + size * 0.95 + i * leading)}" font-size="${size}" font-weight="${b.weight}" fill="${b.color}"${b.align === "center" ? ' text-anchor="middle"' : ""}>${esc5(line)}</text>`).join("");
  }
  throw Error("card_content_overflow");
}
function alternateCard(headline, body, breaking, bg, fg, layout, label) {
  const steel = COLORS.steel;
  const rect = (x, y, w, h, fill, stroke) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}"${stroke ? ` stroke="${stroke}" stroke-width="2"` : ""}/>`;
  const line = (x, y, x2, y2, color = steel, width = 2) => `<path d="M${x} ${y} H${x2}" transform="translate(0 0)" stroke="${color}" stroke-width="${width}"/>`;
  const logo = (x, y, color) => `<image x="${x}" y="${y}" width="72" height="72" xlink:href="${PROFILE_DATA}"/><text x="${x + 94}" y="${y + 33}" fill="${color}" font-size="32" font-weight="700" letter-spacing="1">ENDEKS</text><text x="${x + 96}" y="${y + 61}" fill="${steel}" font-size="18" font-weight="700" letter-spacing="6">HABER</text>`;
  let decoration = "", brand = "", head, detail;
  switch (layout) {
    case "frame":
      decoration = rect(40, 40, 1e3, 1270, "none", steel) + rect(76, 918, 928, 356, fg) + line(76, 230, 1004, 230, fg, 4);
      brand = logo(76, 98, fg);
      head = { x: 88, y: breaking ? 340 : 306, width: 904, height: 550, size: 104, min: 56, weight: 700, color: fg };
      detail = { x: 116, y: 970, width: 848, height: 260, size: 38, min: 30, weight: 400, color: bg };
      break;
    case "rail":
      decoration = rect(0, 0, 70, 1350, fg) + rect(70, 0, 10, 1350, steel) + rect(126, 958, 90, 7, fg) + line(126, 1288, 1e3, 1288);
      brand = logo(126, 90, fg);
      head = { x: 126, y: breaking ? 344 : 300, width: 870, height: 580, size: 102, min: 54, weight: 700, color: fg };
      detail = { x: 250, y: 998, width: 746, height: 255, size: 38, min: 30, weight: 400, color: fg };
      break;
    case "masthead":
      decoration = rect(0, 0, 1080, 824, fg) + rect(76, 820, 168, 8, steel) + line(76, 1178, 1004, 1178);
      brand = logo(76, 1218, fg);
      head = { x: 76, y: breaking ? 218 : 160, width: 928, height: 590, size: 108, min: 56, weight: 700, color: bg };
      detail = { x: 76, y: 894, width: 928, height: 244, size: 40, min: 30, weight: 400, color: fg };
      break;
    case "center":
      decoration = line(76, 220, 1004, 220) + line(430, 926, 650, 926, fg, 5) + line(76, 1276, 1004, 1276);
      brand = logo(385, 80, fg);
      head = { x: 88, y: breaking ? 358 : 310, width: 904, height: 545, size: 102, min: 54, weight: 700, color: fg, align: "center" };
      detail = { x: 140, y: 988, width: 800, height: 245, size: 38, min: 30, weight: 400, color: fg, align: "center" };
      break;
    case "brief":
      decoration = rect(0, 0, 1080, 196, fg) + rect(0, 930, 260, 420, steel) + rect(260, 930, 820, 420, fg) + line(76, 854, 1004, 854, steel, 2);
      brand = logo(76, 62, bg);
      head = { x: 76, y: breaking ? 340 : 286, width: 928, height: 510, size: 106, min: 54, weight: 700, color: fg };
      detail = { x: 310, y: 998, width: 694, height: 288, size: 38, min: 28, weight: 400, color: bg };
      break;
  }
  const breakingY = layout === "masthead" ? 102 : layout === "center" ? 286 : 260;
  const breakingColor = layout === "masthead" ? bg : fg;
  const badge = breaking ? `<text x="${layout === "rail" ? 126 : 76}" y="${breakingY}" font-size="22" font-weight="700" letter-spacing="3" fill="${breakingColor}">${esc5(label)}</text>` : "";
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1080" height="1350" viewBox="0 0 1080 1350" role="img"><title>${BRAND_NAME} \u2014 ${esc5(headline)}</title>${rect(0, 0, 1080, 1350, bg)}<g font-family="Noto Sans">${decoration}${brand}${badge}${fitText(headline, head)}${fitText(body, detail)}</g></svg>`;
}

// src/output-capacity.ts
var OutputCapacityError = class extends Error {
  constructor(code2, diagnostic) {
    super(code2);
    this.diagnostic = diagnostic;
  }
  diagnostic;
};

// src/card-pages.ts
var MAX_CARDS = 4;
var CARD_CAPACITY_MESSAGE = "Se\xE7ilen veri okunakl\u0131 bi\xE7imde d\xF6rt g\xF6rsele s\u0131\u011Fm\u0131yor. Hi\xE7bir sat\u0131r \xE7\u0131kar\u0131lmad\u0131. Kapsam\u0131 daraltabilir veya ayr\u0131ca thread isteyebilirsin; otomatik thread olu\u015Fturulmad\u0131.";
function balancedPages(rows, capacity, pages = Math.max(1, Math.ceil(rows.length / capacity))) {
  if (!Number.isInteger(capacity) || capacity < 1 || !Number.isInteger(pages) || pages < 1 || pages > MAX_CARDS || rows.length > capacity * pages) throw Error("multi_card_capacity_exceeded");
  let start = 0;
  return Array.from({ length: pages }, (_, i) => {
    const n = Math.ceil((rows.length - start) / (pages - i)), part = rows.slice(start, start + n);
    start += n;
    return part;
  });
}
function cardPageDrafts(input) {
  const d = structuredClone(outputView(input)), data = d.card_data;
  if (!data) return [d];
  const fields = [];
  const add = (name, rows, capacity, set) => {
    if (rows) fields.push({ name, rows, capacity, set });
  };
  if (data.report?.buyback) add("buyback.rows", data.report.buyback.rows, 60, (p, r) => {
    p.card_data.report.buyback.rows = r;
    p.card_data.report.buyback.row_count = r.length;
  });
  else if (data.report?.general) add("general.rows", data.report.general.rows, 60, (p, r) => {
    p.card_data.report.general.rows = r;
  });
  else if (data.report) add("report.rows", data.report.rows, 15, (p, r) => {
    p.card_data.report.rows = r;
  });
  else if (d.template === "circuit") add("tickers", data.tickers, 36, (p, r) => {
    p.card_data.tickers = r;
  });
  else {
    const cap = d.template === "institutional" ? 10 : 5;
    for (const side of ["buy", "sell", "holdings"]) add(side, data[side], cap, (p, r) => {
      p.card_data[side] = r;
    });
  }
  const count = Math.max(1, ...fields.map((f) => Math.ceil(f.rows.length / f.capacity)));
  if (count > MAX_CARDS) {
    const diagnostic = { version: 1, kind: "visual", fields: fields.map((f) => ({ name: f.name, rows: f.rows.length, per_card: f.capacity })), required_cards: count, max_cards: MAX_CARDS };
    throw new OutputCapacityError("multi_card_capacity_exceeded", diagnostic);
  }
  const parts = fields.map((f) => balancedPages(f.rows, f.capacity, count));
  return Array.from({ length: count }, (_, i) => {
    const page = structuredClone(d);
    fields.forEach((f, j) => f.set(page, parts[j][i]));
    return page;
  });
}
function draftCards(d, theme, layout = "editorial") {
  const pages = cardPageDrafts(d);
  return pages.map((page, i) => {
    let svg = draftCard(page, [], "", false, theme, layout);
    if (pages.length > 1) {
      const size = /width="(\d+)" height="(\d+)"/.exec(svg);
      if (!size) throw Error("card_dimensions_missing");
      const w = Number(size[1]), h = Number(size[2]);
      svg = svg.replace("</svg>", `<text x="${w - 58}" y="${h - 24}" text-anchor="end" font-family="Noto Sans" font-size="24" fill="#8095A4">${i + 1}/${pages.length}</text></svg>`);
    }
    return svg;
  });
}
function cardSvgs(d, theme, layout = "editorial") {
  return draftCards({ ...d, card_headline: d.card_headline ?? d.headline, card_body: d.card_body ?? d.body }, theme, layout);
}
export {
  CARD_CAPACITY_MESSAGE,
  CIRCUIT_REPORT_LIMIT,
  MAX_CARDS,
  balancedPages,
  cardPageDrafts,
  cardSvg,
  cardSvgs,
  circuitOmissionNote,
  draftCards,
  selectCircuitReport
};
