// src/data/bist-equity-session-2026.json
var bist_equity_session_2026_default = {
  version: "bist-equity-2026-reviewed-2026-10-26",
  year: 2026,
  timezone: "Europe/Istanbul",
  checked_at: "2026-10-26T12:25:43.396161+00:00",
  sources: [
    {
      url: "https://www.borsaistanbul.com/files/pay-piyasasi-2026-yili-tatil-tablosu.pdf",
      sha256: "e45fa97e2f67d85b3571ce9e6c4758292a57379c2216fc88183f32504584e680"
    },
    {
      url: "https://www.borsaistanbul.com/files/pay-piyasasi-proseduru.pdf",
      sha256: "a065530d88acbb4d1548a218dc351077b02003b127588b8b30942d4c26c49c15",
      pages: [
        154,
        155
      ]
    }
  ],
  closed: [
    "2026-01-01",
    "2026-03-20",
    "2026-03-21",
    "2026-03-22",
    "2026-04-23",
    "2026-05-01",
    "2026-05-19",
    "2026-05-27",
    "2026-05-28",
    "2026-05-29",
    "2026-05-30",
    "2026-07-15",
    "2026-08-30",
    "2026-10-29"
  ],
  half: [
    "2026-03-19",
    "2026-05-26",
    "2026-10-28"
  ],
  full: {
    start: 580,
    continuous_start: 600,
    closing_start: 1080,
    end: 1090
  },
  half_session: {
    start: 580,
    continuous_start: 600,
    closing_start: 750,
    end: 760
  },
  editorial: {
    opening_until: 660,
    midday_until: 900
  },
  note: "Session boundaries are official. 11:00/15:00 are owner-authorized editorial divisions, not separate official trading sessions. Unknown years or dates use a neutral title; publication time is not a verified market measurement time."
};

// src/market-session.ts
var EDITORIAL_PERIODS = ["G\xFCne ba\u015Flarken", "A\xE7\u0131l\u0131\u015F\u0131n ilk dakikalar\u0131", "G\xFCn ortas\u0131", "Kapan\u0131\u015Fa do\u011Fru", "Kapan\u0131\u015Fta"];
function equitySessionLabel(at, table = bist_equity_session_2026_default) {
  const base = { label: null, kind: "unknown", reason: "session_unknown", version: table?.version ?? null, basis: "original_channel_publication_time", measurement_time_verified: false };
  if (!at || !/(?:Z|[+-]\d{2}:\d{2})$/i.test(at) || !Number.isFinite(Date.parse(at))) return { ...base, reason: "publication_time_invalid" };
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date(at)), part = (key) => parts.find((p) => p.type === key).value;
  const date = part("year") + "-" + part("month") + "-" + part("day"), minute = Number(part("hour")) * 60 + Number(part("minute"));
  if (!table || Number(part("year")) !== table.year) return { ...base, reason: "calendar_year_unknown" };
  const weekday = (/* @__PURE__ */ new Date(date + "T12:00:00Z")).getUTCDay();
  if (weekday === 0 || weekday === 6 || table.closed.includes(date)) return { ...base, kind: "closed", reason: "market_closed" };
  const half = table.half.includes(date), s = half ? table.half_session : table.full, kind = half ? "half" : "full";
  if (minute < s.start || minute >= s.end) return { ...base, kind, reason: "outside_session" };
  const label = minute < s.continuous_start ? EDITORIAL_PERIODS[0] : minute < s.closing_start ? minute < table.editorial.opening_until ? EDITORIAL_PERIODS[1] : half ? EDITORIAL_PERIODS[3] : minute < table.editorial.midday_until ? EDITORIAL_PERIODS[2] : EDITORIAL_PERIODS[3] : EDITORIAL_PERIODS[4];
  return { ...base, kind, label, reason: "owner_editorial_label" };
}
export {
  EDITORIAL_PERIODS,
  equitySessionLabel
};
